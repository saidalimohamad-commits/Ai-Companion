# AI Learning Companion MVP V1
Static installable PWA. No API keys, video capture, DRM bypass or automatic course ingestion.

## Phone-only setup
1. Unzip the folder using Android Files.
2. Upload the four app files (index.html, manifest.webmanifest, icon.svg, sw.js) to a new public GitHub repository via github.com in Chrome desktop-site mode, or another static HTTPS host you control.
3. On GitHub, go to Settings > Pages, choose Deploy from a branch, main / root, and Save.
4. Open the Pages URL on Android Chrome. Choose menu > Add to Home screen / Install app (availability depends on Chrome and installation criteria).
5. Enter a topic, add your own notes, select a tutoring task, and copy the prompt into ChatGPT.

## Limits
The buttons generate prompts from templates, not AI responses. The app stores notes in localStorage on the device/browser; clearing site data deletes them. GitHub Pages serves the app publicly, so do not upload personal notes, credentials or copyrighted course materials to the repository. A native Android overlay and direct AI integration are future phases.
